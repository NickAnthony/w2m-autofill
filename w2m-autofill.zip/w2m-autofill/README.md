w2m-autofill
============
by Pranav Vishnu Ramabhadran
----------------------------

This Chrome Extension hooks into your Google Calendar and lets you autofill [when2meets](http://www.when2meet.com) using your calendar info. You can download it from the Chrome Store [here](https://chrome.google.com/webstore/detail/when2meet-autofill/cmbibnmlbbkijffhjpbacdgpdodfjjfp).
Please feel free to fork and add in other calendars as well!
